
void testPNG(void);

void testChangementBase(int value, int base, T_list s);

void testGetSize(void);
void testTaillAdd(void);
void testSortAdd(void);
void testInList(void);
void testRemDup(void);